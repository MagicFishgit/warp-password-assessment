import 'dotenv/config';
import axios from 'axios';
import archiver from 'archiver';
import fs from 'fs';

//Create zip file and return as Base64 string.
function createZipBase64(cvPath, sourcePaths, dictPath){
    return new Promise((resolve, reject) => {
        const archive = archiver('zip', { zlib: { level: 9}});
        const buffers = [];

        //Listen for data events, collect buffer chunks.

        archive.on('data', (buffer) => {
            buffers.push(buffer);
        });

//Listen for end event:
archive.on('end', () => {
    const finalBuffer = Buffer.concat(buffers);
    console.log("Zip file created in mem.");
    resolve(finalBuffer.toString('base64'));
});

//Error handling:
archive.on('warning', (err) => reject(err));
archive.on('error', (err) => reject(err));

//Push files to stream:
archive.file(cvPath, {name: 'archived_cv.pdf'});
const codeDirectory = 'source_code';
for (const file of sourcePaths) {
    let zipPath;

    if (file === '../README.md'){
        zipPath = 'README.md';
    }
    // Check if the file path is one of the mock-api files
    else if(file.startsWith('../mock-api/')) {
        
        zipPath = `${codeDirectory}/${file.replace('../', '')}`;
    } else {
        zipPath = `${codeDirectory}/${file}`;
    }

    archive.file(file, { name: zipPath });
}

    archive.finalize();
    });
}

//Submit final payload:
export async function submitResume(tempUrl, cvPath, sourcePaths, dictPath) {

    //Check if resume file exists:
    if (!cvPath || !fs.existsSync(cvPath)){
        console.error(
            `ERROR: Resume file not found!
            Specified path: {$cvPath}, please check that the file exists or the variable is set correctly. `
        );
        return;
    }

    console.log("Creating Zip...");
    const zipAsB64 = await createZipBase64(cvPath, sourcePaths, dictPath);

    //Write the zip file so I can inspect if all the contents required for the test is there.
    const zipBuffer = Buffer.from(zipAsB64, 'base64');
    console.log("Writing zip to file to verify contents manually.");
    fs.writeFileSync('subm.zip', zipBuffer);

    //Check the filesize:
    const fileSizeMB = zipBuffer.length / (1024 * 1024);
    console.log(`Zip Size: ${fileSizeMB.toFixed(2)} MB`);

    if (fileSizeMB > 5) {
        console.error("WARNING: Zip exceeds max filesize of 5MB");
        return
    }

    const payload = {
        data: zipAsB64,
        name: process.env.MY_NAME,
        surname: process.env.MY_SURNAME,
        email: process.env.MY_EMAIL
    };

    console.log(`Posting to ${tempUrl}`);

    try{
        const response = await axios.post(tempUrl, payload, {
            headers: { 'Content-Type': 'application/json' }
        });
        console.log("Submission completed!", response.data.message);
    }catch (error) {
        const errData = error.response?.data || error.message;
        console.error ("Submission Failed!", errData);
    }
}
